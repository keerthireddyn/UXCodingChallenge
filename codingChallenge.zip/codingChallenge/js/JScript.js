var likeCount = 0;

document.addEventListener("DOMContentLoaded", function () {
    var inputEls = document.getElementsByTagName('input');
    for (var i = 0; i < inputEls.length; i++) {
        inputEls[i].value = "0"
    }
})

function likeME(id) {
    likeCount = parseInt(document.getElementById("hdn" + id).value);
    likeCount += 1;
    document.getElementById("hdn" + id).value = likeCount;
    document.getElementById("like-count" + id).innerHTML = likeCount;
    document.getElementById("like-count" + id).style.display = 'inline';

}








